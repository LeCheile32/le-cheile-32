const e = React.createElement;

function useHashRoute() {
  const [route, setRoute] = React.useState(window.location.hash || '#home');
  React.useEffect(() => {
    const onHash = () => setRoute(window.location.hash || '#home');
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  return [route, setRoute];
}

function Home() {
  return e('div', { className:'container hero section' },
    e('h1', null, 'Le Chéile 32'),
    e('p', null, 'A non‑profit community hub for evidence‑based resources, dialogue and support. Shop to support our mission, explore key documents, or get in touch.'),
    e('div', {className:'grid'},
      e('a',{href:'#shop', className:'card btn'}, 'Visit shop'),
      e('a',{href:'#documents', className:'card btn'}, 'Read key documents'),
      e('a',{href:'#videos', className:'card btn'}, 'Watch videos'),
      e('a',{href:'#donate', className:'card btn'}, 'Make a donation')
    )
  );
}

function Shop() {
  const [items, setItems] = React.useState([]);
  React.useEffect(() => {
    fetch('/api/products').then(r=>r.json()).then(setItems);
  }, []);
  return e('div', { className:'container section' },
    e('h2', null, 'Shop'),
    e('div', { className:'grid' },
      items.map(p => e('div', { key:p.id, className:'card' },
        e('img',{src:p.imageUrl, alt:p.name, style:{width:'100%',borderRadius:10}}),
        e('h3', null, p.name),
        e('div',{className:'price'}, '€' + p.price),
        e('p', null, p.description),
        e('button',{className:'btn primary', onClick:()=>alert('Added: '+p.name)}, 'Add to cart')
      ))
    )
  );
}

function Videos() {
  return e('div', { className:'container section' },
    e('h2', null, 'Videos'),
    e('p', {className:'small'}, 'Curated explainers and recent events (YouTube).'),
    e('div', {className:'grid'},
      e('iframe', {width:'100%', height:240, src:'https://www.youtube.com/embed?listType=search&list=Good%20Friday%20Agreement', title:'GFA search', allow:'accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture', allowFullScreen:true}),
      e('iframe', {width:'100%', height:240, src:'https://www.youtube.com/embed?listType=search&list=Ireland%27s%20Future', title:'Ireland\'s Future', allow:'accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture', allowFullScreen:true})
    )
  );
}

function Documents() {
  const [groups, setGroups] = React.useState([]);
  React.useEffect(()=>{ fetch('/api/documents').then(r=>r.json()).then(setGroups); },[]);
  return e('div', { className:'container section' },
    e('h2', null, 'Documents & Resources'),
    groups.map((g, idx) => e('div', { key:idx, className:'card', style:{padding:18} },
      e('h3', null, g.category),
      e('div', {className:'list'},
        g.items.map((it, i) => e('div', { key:i },
          e('a', { href: it.url, target:'_blank', rel:'noopener' }, it.title, ' →'),
          e('div', { className:'small' }, (it.source ? (it.source+' — ') : '') + (it.blurb || ''))
        ))
      )
    ))
  );
}

function Gallery() {
  const imgs = [
    'https://source.unsplash.com/featured/600x400/?ireland,community',
    'https://source.unsplash.com/featured/600x400/?diaspora,people',
    'https://source.unsplash.com/featured/600x400/?heritage,culture',
  ];
  return e('div',{className:'container section'},
    e('h2', null, 'Gallery'),
    e('div',{className:'grid'},
      imgs.map((src,i)=>e('img',{key:i, src, alt:'gallery', style:{width:'100%',borderRadius:12}}))
    )
  );
}

function Contact() {
  const [form, setForm] = React.useState({name:'', email:'', message:''});
  function update(k,v){ setForm({...form, [k]:v}); }
  function submit(evn){ evn.preventDefault(); alert('Thanks, we will be in touch.'); }
  return e('div',{className:'container section'},
    e('h2', null, 'Contact'),
    e('form',{className:'card', onSubmit:submit, style:{padding:18}},
      e('div',{className:'row'},
        e('input',{className:'input', placeholder:'Your name', value:form.name, onChange:e=>update('name',e.target.value)}),
        e('input',{className:'input', type:'email', placeholder:'Email', value:form.email, onChange:e=>update('email',e.target.value)})
      ),
      e('textarea',{className:'input', rows:5, placeholder:'Message', value:form.message, onChange:e=>update('message',e.target.value), style:{marginTop:12}}),
      e('div', {style:{marginTop:12}},
        e('button',{className:'btn primary', type:'submit'},'Send')
      )
    )
  );
}

function Donate() {
  function handle() {
    alert('Patreon/Stripe link coming soon. For now this records your intent.');
    fetch('/api/donate', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ amount:'tbd' })});
  }
  return e('div',{className:'container section'},
    e('h2', null, 'Donate'),
    e('p', null, 'We will add a Patreon/Stripe link here when ready.'),
    e('button',{className:'btn primary', onClick:handle}, 'Donate')
  );
}

function App(){
  const [route] = useHashRoute();
  let view = Home;
  if (route.startsWith('#shop')) view = Shop;
  if (route.startsWith('#videos')) view = Videos;
  if (route.startsWith('#documents')) view = Documents;
  if (route.startsWith('#gallery')) view = Gallery;
  if (route.startsWith('#contact')) view = Contact;
  if (route.startsWith('#donate')) view = Donate;
  return e(view);
}

ReactDOM.createRoot(document.getElementById('app')).render(e(App));
