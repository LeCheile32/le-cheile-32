/*
 * Simple HTTP server for Le Chéile 32 – turnkey, no npm install required.
 * Serves the frontend and exposes a minimal JSON API.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

// Load data files
const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'products.json'), 'utf8'));
const docs = JSON.parse(fs.readFileSync(path.join(__dirname, 'documents.json'), 'utf8'));

// Helpers
function sendJSON(res, obj, status=200) {
  const data = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(data);
}

function serveStatic(req, res) {
  let pathname = url.parse(req.url).pathname;
  if (pathname === '/' || pathname === '/index.html') {
    pathname = '/index.html';
  }
  const filePath = path.normalize(path.join(FRONTEND_DIR, pathname));
  if (!filePath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404); res.end('Not Found'); return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const types = {'.html': 'text/html; charset=utf-8', '.css':'text/css', '.js':'text/javascript', '.json':'application/json', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.svg':'image/svg+xml'};
    res.writeHead(200, {'Content-Type': types[ext] || 'application/octet-stream'});
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  const { pathname } = url.parse(req.url);

  // API routes
  if (pathname === '/api/products') return sendJSON(res, products);
  if (pathname === '/api/documents') return sendJSON(res, docs);
  if (pathname === '/api/health') return sendJSON(res, { ok: true, name: 'Le Chéile 32' });

  // Simple donate endpoint (logs only for now)
  if (pathname === '/api/donate' && req.method === 'POST') {
    let body='';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      console.log('Donate payload:', body);
      return sendJSON(res, { received: true });
    });
    return;
  }

  // Static files
  serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`Le Chéile 32 server running on http://localhost:${PORT}`);
});
